import React, { useState } from 'react';
import { View, Text, TextInput, Button, Alert, StyleSheet } from 'react-native';
import axios from 'axios';

export default function CityScreen() {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState(null);

  const handleCheckWeather = async () => {
    const allowedCities = ['rawalpindi', 'islamabad'];
    if (!allowedCities.includes(city.toLowerCase())) {
      Alert.alert('Error', 'This city is not allowed.');
      return;
    }

    try {
      const apiKey = 'YOUR_OPENWEATHERMAP_API_KEY';
      const response = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`
      );

      const temp = response.data.main.temp;
      setWeather({ name: city, temp });
    } catch (error) {
      Alert.alert('Error', 'Failed to fetch weather.');
    }
  };

  return (
    <View style={styles.container}>
      <Text>Enter City Name:</Text>
      <TextInput style={styles.input} value={city} onChangeText={setCity} />
      <Button title="Get Weather" onPress={handleCheckWeather} />
      {weather && (
        <View style={styles.result}>
          <Text>City: {weather.name}</Text>
          <Text>Temperature: {weather.temp} °C</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: 'center' },
  input: { borderWidth: 1, padding: 10, marginVertical: 10, borderRadius: 5 },
  result: { marginTop: 20 },
});
